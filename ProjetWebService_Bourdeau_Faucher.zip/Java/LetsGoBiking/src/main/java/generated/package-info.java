@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://schemas.datacontract.org/2004/07/test", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package generated;
